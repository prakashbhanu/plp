package com.cg.service;

import java.util.Date;
import java.util.List;

import org.hibernate.criterion.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.InvoiceDao;
import com.cg.model.Invoice;

@Service("invoiceService")
public class InvoiceServiceImpl implements InvoiceService{

	@Autowired
	InvoiceDao invoiceDao;
	
	@Autowired(required=false)
	IOrderService orderService;
	
	@Override
	public Invoice getInvoiceFromOrderId(int OrderId) {
		
		Order myOrder = orderService.findOrderById(OrderId);
		
		List<Invoice> invoices = invoiceDao.findAll();
		
		for(Invoice myInvoice: invoices) {
			if(myInvoice.getOrder().equals(myOrder)) {
				return myInvoice;
			}
		}
		return null;
	}

	@Override
	public boolean generateInvoice(Invoice invoice) {
		
		invoiceDao.save(invoice);
		
		return true;
	}

	@Override
	public List<Invoice> getInvoiceDetailsBetweenDates(Date fromDate, Date toDate) {
		List<Invoice> invoiceDetails=invoiceDao.getInvoiceDetailsBetweenDates(fromDate, toDate);
		return invoiceDetails;
	}
	
	public void createProduct(Invoice invoice) {

		System.out.println("Creating new invoice : "+ invoice.getInvoiceNo());

		invoiceDao.save(invoice);

	} 
}