package com.cg.model;
import java.io.Serializable;

import java.util.Date;
import java.util.List;

import javax.persistence.*;
@Entity

@Table(name="product")

public class Product {
	
	
	 @Id

	 @GeneratedValue(strategy = GenerationType.AUTO)

	 @Column(name="PID")

	 private int pid;



	 @Column(name="PNAME")

	 private String pname;



	 @Column(name="PRICE")

	 private int price;



	/* @Column(name="IMAGEURL")

	 private String imageUrl;



	 @Column(name="CATOGORY")

	 private String catogory;



	 @Column(name="MODEL")

	 private String model;



	 @Column(name="UPLOADA_DATE")

	 private Date date;



	 @Column(name="QUANTITY")

	 private int quantity;



	 @Column(name="DESCRIPTION")

	 private String description;



	 @Column(name="RATINGS")

	 private int ratings;



	 @Column(name="DISCOUNT")

	 private int discount;



	 @Column(name="PROMOCODE")

	 private String promocode;



	 @Column(name="FEEDBACK")

	 private String feedback;



	 @Column(name="MID")

	 private int mid;
	 
	 @ManyToMany(mappedBy="product")
	 private List<Order> order;

	/*



	 @Column(name="OID")

	 private int oid;





	 @Column(name="CATID")

	 private int catId;*/



	/*

	 public int getOid() {

	 return oid;

	 }



	 public void setOid(int oid) {

	 this.oid = oid;

	 }



	 public int getCatId() {

	 return catId;

	 }



	 public void setCatId(int catId) {

	 this.catId = catId;

	 }



	 public int getMid() {

	 return mid;

	 }



	 public void setMid(int mid) {

	 this.mid = mid;

	 }



//		@ManyToOne

//		@JoinColumn(name="mid")

//		Merchant mer;



	 public String getFeedback() {

	 return feedback;

	 }



	 public void setFeedback(String feedback) {

	 this.feedback = feedback;

	 }*/



	 public int getPid() {

	 return pid;

	 }



	 public void setPid(int pid) {

	 this.pid = pid;

	 }



	 public String getPname() {

	 return pname;

	 }



	 public void setPname(String pname) {

	 this.pname = pname;

	 }



	 public int getPrice() {

	 return price;

	 }



	 public void setPrice(int price) {

	 this.price = price;

	 }



	/* public String getImageUrl() {

	 return imageUrl;

	 }



	 public void setImageUrl(String imageUrl) {

	 this.imageUrl = imageUrl;

	 }



	 public String getCatogory() {

	 return catogory;

	 }



	 public void setCatogory(String catogory) {

	 this.catogory = catogory;

	 }



	 public String getModel() {

	 return model;

	 }



	 public void setModel(String model) {

	 this.model = model;

	 }



	 public Date getDate() {

	 return date;

	 }



	 public void setDate(Date date) {

	 this.date = date;

	 }



	 public int getQuantity() {

	 return quantity;

	 }



	 public void setQuantity(int quantity) {

	 this.quantity = quantity;

	 }



	 public String getDescription() {

	 return description;

	 }



	 public void setDescription(String description) {

	 this.description = description;

	 }



	 public int getRatings() {

	 return ratings;

	 }



	 public void setRatings(int ratings) {

	 this.ratings = ratings;

	 }



	 public int getDiscount() {

	 return discount;

	 }



	 public void setDiscount(int discount) {

	 this.discount = discount;

	 }



	 public String getPromocode() {

	 return promocode;

	 }



	 public void setPromocode(String promocode) {

	 this.promocode = promocode;

	 }

*/





	 public Product() {

	 // TODO Auto-generated constructor stub

	 }







	 @Override

	 public String toString() {

	 return "Product [pid=" + pid + ", pname=" + pname + ", price=" + price +  

	   "]";

	 }



	 public Product(int pid, String pname, int price ) {

	 super();

	 this.pid = pid;

	 this.pname = pname;

	 this.price = price;

	 /*this.imageUrl = imageUrl;

	 this.catogory = catogory;

	 this.model = model;

	 this.date = date;

	 this.quantity = quantity;

	 this.description = description;

	 this.ratings = ratings;

	 this.discount = discount;

	 this.promocode = promocode;

	 this.feedback = feedback;

	 this.mid = mid;

	 	this.oid = oid;

	 this.catId = catId;*/
	 }
	
	
	

}
