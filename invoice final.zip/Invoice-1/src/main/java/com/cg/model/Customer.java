package com.cg.model;
import java.io.Serializable;

import java.util.Date;



import javax.persistence.*;


@Entity
public class Customer {
	

	 @Id
	 @GeneratedValue(strategy = GenerationType.AUTO)

	 private int cid;

	 @Column(name="CNAME")
	 private String cname;



	/* @Column(name="CMOBILENUMBER")
	 private String mobileNumber;



	 @Column(name="CEMAIL")
	 private String email;



	 @Column(name="PASSWORD")
	 private String passwod;



	 @Column(name="CREATED_DATE")
	 private Date date;



	 @Column(name="LOGINTIME")
	 private Date loginTime;



	 @Column(name="LOGOUTTIME")
	 private Date logoutTime;

*/

	 @Column(name="REFERENCENUMBER")
	 private int refNumber;
	 
	 @OneToOne(mappedBy="customer")
	 private Order order;



	 public int getCid() {

	 return cid;

	 }



	 public void setCid(int cid) {

	 this.cid = cid;

	 }



	 public String getCname() {

	 return cname;

	 }



	 public void setCname(String cname) {

	 this.cname = cname;

	 }


/*
	 public String getMobileNumber() {

	 return mobileNumber;

	 }



	 public void setMobileNumber(String mobileNumber) {

	 this.mobileNumber = mobileNumber;

	 }



	 public String getEmail() {

	 return email;

	 }



	 public void setEmail(String email) {

	 this.email = email;

	 }



	 public String getPasswod() {

	 return passwod;

	 }



	 public void setPasswod(String passwod) {

	 this.passwod = passwod;

	 }



	 public Date getDate() {

	 return date;

	 }



	 public void setDate(Date date) {

	 this.date = date;

	 }



	 public Date getLoginTime() {

	 return loginTime;

	 }



	 public void setLoginTime(Date loginTime) {

	 this.loginTime = loginTime;

	 }



	 public Date getLogoutTime() {

	 return logoutTime;

	 }



	 public void setLogoutTime(Date logoutTime) {

	 this.logoutTime = logoutTime;

	 }



	 public int getRefNumber() {

	 return refNumber;

	 }



	 public void setRefNumber(int refNumber) {

	 this.refNumber = refNumber;

	 }*/

	public Customer() {

	 // TODO Auto-generated constructor stub

	}

	 public Customer(int cid, String cname) {

	 super();

	 this.cid = cid;

	 this.cname = cname;

	/* this.mobileNumber = mobileNumber;

	 this.email = email;

	 this.passwod = passwod;

	 this.date = date;

	 this.loginTime = loginTime;

	 this.logoutTime = logoutTime;

	 this.refNumber = refNumber;*/

	 }



	 @Override

	 public String toString() {

	 return "Customer [cid=" + cid + ", cname=" + cname +  "]";

	 }


	
	

}
