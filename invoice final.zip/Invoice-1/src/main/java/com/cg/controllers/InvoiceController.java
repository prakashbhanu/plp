 package com.cg.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.model.Invoice;
import com.cg.service.InvoiceService;


//@CrossOrigin(origins="*")
@RestController
@RequestMapping("/api/v1")
public class InvoiceController {
	
	
	@Autowired
	private InvoiceService invoiceService;
	
	/*@PostMapping(value = "/invoice")
	public ResponseEntity<Invoice> insertShipment(@RequestBody Invoice invoice) {
		System.out.println("add customer");
		System.out.println(invoice);
		
		Invoice invoice1=invoiceService.insertInvoice(invoice);
		
		if(invoice==null)
			return new ResponseEntity("Insertion Failed",HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<Invoice>(invoice1,HttpStatus.OK);
	}*/
	
	@GetMapping(value = "/getinvoice/{OrderId}")
	public ResponseEntity<Invoice> getInvoice(@PathVariable("OrderId") Integer orderId){
		
		Invoice requiredInvoice = invoiceService.getInvoiceFromOrderId(orderId);
		
		return new ResponseEntity<Invoice>(requiredInvoice, HttpStatus.OK);
		
	}
	
	@PostMapping(value="/createProduct",consumes= {"application/xml","application/json"})
	public ResponseEntity<Integer> createcart(@RequestBody Invoice invoice){
		
		System.out.println("Create method");
		System.out.println(invoice.getInvoiceNo());
		invoiceService.createProduct(invoice);

		return new ResponseEntity<Integer>(HttpStatus.CREATED);

	} 
	
}